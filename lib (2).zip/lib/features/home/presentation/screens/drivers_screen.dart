import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/dashboard/dashboard_layout.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/constants/app_routes.dart';

import 'package:driver_app_dash/features/drivers/data/models/driver_model.dart';
import 'package:driver_app_dash/features/drivers/presentation/cubit/driver_cubit.dart';

class DriversScreen extends StatelessWidget {
  const DriversScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardLayout(
      activeRoute: AppRoutes.drivers,
      pageTitle: 'السائقون',
      body: const _DriversBody(),
    );
  }
}

// ============================================================================
// DRIVERS BODY
// ============================================================================

const _statusOptions = <String, String>{
  '': 'كل الحالات',
  'active': 'نشط',
  'inactive': 'غير نشط',
};

class _DriversBody extends StatefulWidget {
  const _DriversBody();

  @override
  State<_DriversBody> createState() => _DriversBodyState();
}

class _DriversBodyState extends State<_DriversBody> {
  String _search = '';
  String _statusFilter = '';

  @override
  void initState() {
    super.initState();
    context.read<DriverCubit>().load();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<DriverCubit, DriverState>(
      listener: (ctx, state) {
        if (state is DriverError) {
          ScaffoldMessenger.of(ctx).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.danger),
          );
        }
      },
      builder: (ctx, state) {
        final drivers = switch (state) {
          DriverLoaded() => state.drivers,
          DriverSubmitting() => state.drivers,
          DriverError() => state.drivers ?? [],
          _ => <DriverModel>[],
        };

        final query = _search.trim().toLowerCase();

        final filtered = drivers.where((d) {
          final matchesSearch = query.isEmpty ||
              d.name.toLowerCase().contains(query) ||
              d.phone.toLowerCase().contains(query) ||
              (d.email?.toLowerCase().contains(query) ?? false);
          final matchesStatus = _statusFilter.isEmpty || d.status == _statusFilter;
          return matchesSearch && matchesStatus;
        }).toList();

        final isLoading = state is DriverLoading;
        final isSubmitting = state is DriverSubmitting;

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ──────────────────────────────────────────────
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('إدارة السائقين',
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                        const SizedBox(height: 3),
                        Text('${drivers.length} سائق مسجل',
                            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  AppButton(
                    label: 'إضافة سائق',
                    icon: Icons.add,
                    width: 150,
                    height: 40,
                    onPressed: () => _showForm(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // ── Search + status filter ────────────────────────────────
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 42,
                      child: TextField(
                        onChanged: (v) => setState(() => _search = v),
                        decoration: InputDecoration(
                          hintText: 'بحث بالاسم أو رقم الهاتف أو البريد...',
                          prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.textHint),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                          filled: true,
                          fillColor: AppColors.surface,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.primary)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    height: 42,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _statusFilter,
                        items: _statusOptions.entries
                            .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, style: const TextStyle(fontSize: 13))))
                            .toList(),
                        onChanged: (v) => setState(() => _statusFilter = v ?? ''),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ── Table ──────────────────────────────────────────────
              Expanded(
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : filtered.isEmpty
                        ? _EmptyState(onAdd: () => _showForm(ctx))
                        : _DriverTable(
                            drivers: filtered,
                            isSubmitting: isSubmitting,
                            onEdit: (d) => _showForm(ctx, driver: d),
                            onDelete: (d) => _confirmDelete(ctx, d),
                            onResetPassword: (d) => _resetPassword(ctx, d),
                          ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _showForm(BuildContext context, {DriverModel? driver}) async {
    // A non-null result only comes back from a successful "create" —
    // (driver name, one-time temporary password).
    final result = await showDialog<(String, String)>(
      context: context,
      barrierDismissible: false,
      builder: (_) => BlocProvider.value(
        value: context.read<DriverCubit>(),
        child: _DriverFormDialog(driver: driver),
      ),
    );

    if (result != null && context.mounted) {
      _showTempPasswordDialog(context, driverName: result.$1, tempPassword: result.$2);
    }
  }

  void _confirmDelete(BuildContext context, DriverModel driver) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Row(children: [
          Icon(Icons.warning_amber_rounded, color: AppColors.danger, size: 22),
          SizedBox(width: 8),
          Text('تأكيد الحذف', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        ]),
        content: Text(
          'هل أنت متأكد من حذف السائق "${driver.name}"؟\nسيتم إنهاء ربطه بأي مركبة وإلغاء جلساته الحالية. لا يمكن التراجع عن هذا الإجراء.',
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.pop(dialogContext);
              context.read<DriverCubit>().delete(driver.id);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _resetPassword(BuildContext context, DriverModel driver) async {
    final cubit = context.read<DriverCubit>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('إعادة تعيين كلمة المرور', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        content: Text(
          'سيتم إنشاء كلمة مرور مؤقتة جديدة لـ "${driver.name}" وإلغاء كل جلساته الحالية. هل تريد المتابعة؟',
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('متابعة')),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    final tempPassword = await cubit.resetPassword(driver.id);
    if (!context.mounted || tempPassword == null) return;

    _showTempPasswordDialog(context, driverName: driver.name, tempPassword: tempPassword);
  }

  void _showTempPasswordDialog(BuildContext context, {required String driverName, required String tempPassword}) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Row(children: [
          Icon(Icons.vpn_key_outlined, color: AppColors.success, size: 22),
          SizedBox(width: 8),
          Text('كلمة المرور المؤقتة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('سلّم كلمة المرور هذه لـ "$driverName" — لن تظهر مرة أخرى:',
                style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6)),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(8)),
              child: SelectableText(
                tempPassword.isEmpty ? '(فارغة — راجع استجابة الخادم)' : tempPassword,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary, letterSpacing: 1),
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('تم')),
        ],
      ),
    );
  }
}

// ============================================================================
// TABLE
// ============================================================================

class _DriverTable extends StatelessWidget {
  final List<DriverModel> drivers;
  final bool isSubmitting;
  final void Function(DriverModel) onEdit;
  final void Function(DriverModel) onDelete;
  final void Function(DriverModel) onResetPassword;

  const _DriverTable({
    required this.drivers,
    required this.isSubmitting,
    required this.onEdit,
    required this.onDelete,
    required this.onResetPassword,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: const BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
              border: Border(bottom: BorderSide(color: AppColors.border)),
            ),
            child: const Row(children: [
              Expanded(flex: 3, child: _HeaderCell('السائق')),
              Expanded(flex: 2, child: _HeaderCell('الهاتف')),
              Expanded(flex: 2, child: _HeaderCell('المركبة المرتبطة', centered: true)),
              Expanded(flex: 2, child: _HeaderCell('الحالة', centered: true)),
              SizedBox(width: 130, child: _HeaderCell('إجراءات', centered: true)),
            ]),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: drivers.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
              itemBuilder: (_, i) {
                final d = drivers[i];
                return Opacity(
                  opacity: isSubmitting ? .6 : 1,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    child: Row(children: [
                      Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(d.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                            if (d.email != null && d.email!.isNotEmpty)
                              Text(d.email!, style: const TextStyle(fontSize: 11, color: AppColors.textHint)),
                          ],
                        ),
                      ),
                      Expanded(flex: 2, child: Text(d.phone, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary))),
                      Expanded(
                        flex: 2,
                        child: Text(d.assignedVehiclePlate ?? '—',
                            textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                      ),
                      Expanded(flex: 2, child: Center(child: _StatusChip(active: d.isActive))),
                      SizedBox(
                        width: 130,
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          _ActionBtn(icon: Icons.edit_outlined, color: AppColors.primary, tooltip: 'تعديل', onTap: () => onEdit(d)),
                          const SizedBox(width: 6),
                          _ActionBtn(icon: Icons.vpn_key_outlined, color: AppColors.warning, tooltip: 'إعادة تعيين كلمة المرور', onTap: () => onResetPassword(d)),
                          const SizedBox(width: 6),
                          _ActionBtn(icon: Icons.delete_outline, color: AppColors.danger, tooltip: 'حذف', onTap: () => onDelete(d)),
                        ]),
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderCell extends StatelessWidget {
  final String label;
  final bool centered;
  const _HeaderCell(this.label, {this.centered = false});

  @override
  Widget build(BuildContext context) => Text(
        label,
        textAlign: centered ? TextAlign.center : TextAlign.start,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
      );
}

class _StatusChip extends StatelessWidget {
  final bool active;
  const _StatusChip({required this.active});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: active ? AppColors.successSurface : AppColors.dangerSurface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: active ? AppColors.success : AppColors.danger)),
          const SizedBox(width: 5),
          Text(active ? 'نشط' : 'غير نشط',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: active ? AppColors.success : AppColors.danger)),
        ]),
      );
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.color, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(6),
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: color.withOpacity(.08), borderRadius: BorderRadius.circular(6)),
            child: Icon(icon, size: 16, color: color),
          ),
        ),
      );
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(color: AppColors.primarySurface, borderRadius: BorderRadius.circular(20)),
            child: const Icon(Icons.people_outline, size: 36, color: AppColors.primary),
          ),
          const SizedBox(height: 16),
          const Text('لا يوجد سائقون بعد', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          const Text('ابدأ بإضافة أول سائق في الشركة', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(height: 20),
          AppButton(label: 'إضافة سائق', icon: Icons.add, width: 160, height: 40, onPressed: onAdd),
        ]),
      );
}

// ============================================================================
// FORM DIALOG
// ============================================================================

class _DriverFormDialog extends StatefulWidget {
  final DriverModel? driver;
  const _DriverFormDialog({this.driver});

  @override
  State<_DriverFormDialog> createState() => _DriverFormDialogState();
}

class _DriverFormDialogState extends State<_DriverFormDialog> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _email;

  String? _status; // edit-only

  bool _isSubmitting = false;
  String? _errorText;

  bool get _isEdit => widget.driver != null;

  @override
  void initState() {
    super.initState();
    final d = widget.driver;
    _name = TextEditingController(text: d?.name ?? '');
    _phone = TextEditingController(text: d?.phone ?? '');
    _email = TextEditingController(text: d?.email ?? '');
    _status = d?.status;
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _email.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_isSubmitting) return;

    setState(() {
      _isSubmitting = true;
      _errorText = null;
    });

    final cubit = context.read<DriverCubit>();

    if (_isEdit) {
      final body = <String, dynamic>{
        'name': _name.text.trim(),
        'phone': _phone.text.trim(),
        if (_email.text.trim().isNotEmpty) 'email': _email.text.trim(),
        if (_status != null) 'status': _status,
      };
      final success = await cubit.update(widget.driver!.id, body);
      if (!mounted) return;
      if (success) {
        Navigator.pop(context);
      } else {
        final state = cubit.state;
        setState(() {
          _isSubmitting = false;
          _errorText = state is DriverError ? state.message : 'حدث خطأ، حاول مرة أخرى';
        });
      }
    } else {
      final body = <String, dynamic>{
        'name': _name.text.trim(),
        'phone': _phone.text.trim(),
        'email': _email.text.trim().isEmpty ? null : _email.text.trim(),
      };
      final tempPassword = await cubit.create(body);
      if (!mounted) return;
      if (tempPassword != null) {
        Navigator.pop(context, (_name.text.trim(), tempPassword));
      } else {
        final state = cubit.state;
        setState(() {
          _isSubmitting = false;
          _errorText = state is DriverError ? state.message : 'حدث خطأ، حاول مرة أخرى';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isEdit ? 'تعديل سائق' : 'إضافة سائق',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 18),

                AppTextField(
                  label: 'الاسم',
                  hint: 'اسم السائق',
                  controller: _name,
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'الاسم مطلوب' : null,
                ),
                const SizedBox(height: 14),

                AppTextField(
                  label: 'رقم الهاتف',
                  hint: '0555111222',
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'رقم الهاتف مطلوب' : null,
                ),
                const SizedBox(height: 14),

                AppTextField(
                  label: 'البريد الإلكتروني (اختياري)',
                  hint: 'driver@example.com',
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 14),

                if (_isEdit) ...[
                  const Text('الحالة', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                  const SizedBox(height: 6),
                  Container(
                    height: 46,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceInput,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String?>(
                        value: _status,
                        isExpanded: true,
                        items: const [
                          DropdownMenuItem(value: 'active', child: Text('نشط', style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'inactive', child: Text('غير نشط', style: TextStyle(fontSize: 13))),
                        ],
                        onChanged: (v) => setState(() => _status = v),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                ] else ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppColors.primarySurface, borderRadius: BorderRadius.circular(8)),
                    child: const Text(
                      'سيتم إنشاء كلمة مرور مؤقتة تلقائياً — سلّمها للسائق يدوياً بعد الإضافة.',
                      style: TextStyle(fontSize: 11, color: AppColors.primaryDark, height: 1.5),
                    ),
                  ),
                  const SizedBox(height: 14),
                ],

                if (_errorText != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppColors.dangerSurface, borderRadius: BorderRadius.circular(8)),
                    child: Text(_errorText!, style: const TextStyle(fontSize: 12, color: AppColors.danger)),
                  ),
                  const SizedBox(height: 14),
                ],

                Row(children: [
                  Expanded(
                    child: TextButton(
                      onPressed: _isSubmitting ? null : () => Navigator.pop(context),
                      child: const Text('إلغاء', style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppButton(
                      label: _isEdit ? 'حفظ' : 'إضافة',
                      isLoading: _isSubmitting,
                      onPressed: _submit,
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
