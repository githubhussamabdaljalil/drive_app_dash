import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/dashboard/dashboard_layout.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/constants/app_routes.dart';

import 'package:driver_app_dash/features/vehicles/data/models/vehicle_model.dart';
import 'package:driver_app_dash/features/vehicles/presentation/cubit/vehicle_cubit.dart';
import 'package:driver_app_dash/features/qr_codes/presentation/cubit/qr_code_cubit.dart';

class QrCodesScreen extends StatelessWidget {
  const QrCodesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardLayout(
      activeRoute: AppRoutes.qrCodes,
      pageTitle: 'رموز QR',
      body: const _QrCodesBody(),
    );
  }
}

class _QrCodesBody extends StatefulWidget {
  const _QrCodesBody();

  @override
  State<_QrCodesBody> createState() => _QrCodesBodyState();
}

class _QrCodesBodyState extends State<_QrCodesBody> {
  VehicleModel? _selected;

  @override
  void initState() {
    super.initState();
    context.read<VehicleCubit>().load();
  }

  void _selectVehicle(VehicleModel v) {
    setState(() => _selected = v);
    context.read<QrCodeCubit>().load(v.id);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VehicleCubit, VehicleState>(
      builder: (ctx, vState) {
        final vehicles = switch (vState) {
          VehicleLoaded() => vState.vehicles,
          VehicleSubmitting() => vState.vehicles,
          VehicleError() => vState.vehicles ?? [],
          _ => <VehicleModel>[],
        };
        final isLoadingVehicles = vState is VehicleLoading;

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('رموز QR للمركبات',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              const SizedBox(height: 3),
              const Text('اختر مركبة لعرض أو توليد أو إلغاء رمز الربط الخاص بها',
                  style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
              const SizedBox(height: 20),

              if (isLoadingVehicles)
                const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator()))
              else if (vehicles.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('لا توجد مركبات مسجلة بعد — أضف مركبة أولاً من صفحة المركبات.',
                      style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                )
              else
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ── Vehicle list ─────────────────────────────────
                    SizedBox(
                      width: 260,
                      child: Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: ListView.separated(
                          shrinkWrap: true,
                          padding: const EdgeInsets.all(6),
                          itemCount: vehicles.length,
                          separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
                          itemBuilder: (_, i) {
                            final v = vehicles[i];
                            final isSelected = _selected?.id == v.id;
                            return InkWell(
                              onTap: () => _selectVehicle(v),
                              borderRadius: BorderRadius.circular(8),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                                decoration: BoxDecoration(
                                  color: isSelected ? AppColors.primarySurface : null,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(v.plateNo,
                                        style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: isSelected ? AppColors.primary : AppColors.textPrimary)),
                                    if (v.model != null)
                                      Text(v.model!, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),

                    // ── QR panel ─────────────────────────────────────
                    Expanded(
                      child: _selected == null
                          ? const _NoSelection()
                          : _QrPanel(vehicle: _selected!),
                    ),
                  ],
                ),
            ],
          ),
        );
      },
    );
  }
}

class _NoSelection extends StatelessWidget {
  const _NoSelection();

  @override
  Widget build(BuildContext context) => Container(
        height: 300,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: const Text('اختر مركبة من القائمة', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
      );
}

class _QrPanel extends StatelessWidget {
  final VehicleModel vehicle;
  const _QrPanel({required this.vehicle});

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<QrCodeCubit, QrCodeState>(
      listener: (ctx, state) {
        if (state is QrCodeError) {
          ScaffoldMessenger.of(ctx).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.danger),
          );
        }
      },
      builder: (ctx, state) {
        final isLoading = state is QrCodeLoading;
        final isSubmitting = state is QrCodeSubmitting;
        final code = switch (state) {
          QrCodeLoaded() => state.code,
          QrCodeSubmitting() => state.code,
          QrCodeError() => state.code,
          _ => null,
        };

        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(vehicle.plateNo, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              const SizedBox(height: 20),
              if (isLoading)
                const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()))
              else if (code == null)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('لا يوجد رمز نشط لهذه المركبة بعد.', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                    const SizedBox(height: 16),
                    AppButton(
                      label: 'توليد رمز جديد',
                      icon: Icons.qr_code_2_outlined,
                      width: 220,
                      isLoading: isSubmitting,
                      onPressed: () => ctx.read<QrCodeCubit>().generate(vehicle.id),
                    ),
                  ],
                )
              else
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Rendered as selectable text — a driver can type this
                    // code manually (no camera required, per the API docs).
                    // Swap for a real QR image with the `qr_flutter` package
                    // if you add it to pubspec.yaml.
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                      decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(10)),
                      child: Center(
                        child: SelectableText(
                          code.code,
                          textAlign: TextAlign.center,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 3, color: AppColors.textPrimary),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (code.createdAt != null)
                      Text('أُنشئ: ${code.createdAt}', style: const TextStyle(fontSize: 11, color: AppColors.textHint)),
                    const SizedBox(height: 16),
                    Row(children: [
                      Expanded(
                        child: AppButton(
                          label: 'إعادة توليد',
                          icon: Icons.refresh,
                          backgroundColor: AppColors.primary,
                          isLoading: isSubmitting,
                          onPressed: () => ctx.read<QrCodeCubit>().generate(vehicle.id),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: AppButton(
                          label: 'إلغاء الرمز',
                          icon: Icons.block_outlined,
                          backgroundColor: AppColors.danger,
                          isLoading: isSubmitting,
                          onPressed: () => ctx.read<QrCodeCubit>().revoke(vehicle.id),
                        ),
                      ),
                    ]),
                    const SizedBox(height: 6),
                    const Text(
                      'إعادة التوليد تُبطل الرمز الحالي فوراً ولا يعود يعمل بعدها.',
                      style: TextStyle(fontSize: 11, color: AppColors.textHint, height: 1.5),
                    ),
                  ],
                ),
            ],
          ),
        );
      },
    );
  }
}
