import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/dashboard/dashboard_layout.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/constants/app_routes.dart';

import 'package:driver_app_dash/features/sub_managers/data/models/sub_manager_model.dart';
import 'package:driver_app_dash/features/sub_managers/presentation/cubit/sub_manager_cubit.dart';

class SubManagersScreen extends StatelessWidget {
  const SubManagersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardLayout(
      activeRoute: AppRoutes.subManagers,
      pageTitle: 'المدراء الفرعيون',
      body: const _SubManagersBody(),
    );
  }
}

class _SubManagersBody extends StatefulWidget {
  const _SubManagersBody();

  @override
  State<_SubManagersBody> createState() => _SubManagersBodyState();
}

class _SubManagersBodyState extends State<_SubManagersBody> {
  @override
  void initState() {
    super.initState();
    context.read<SubManagerCubit>().load();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<SubManagerCubit, SubManagerState>(
      listener: (ctx, state) {
        if (state is SubManagerError) {
          ScaffoldMessenger.of(ctx).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.danger),
          );
        }
      },
      builder: (ctx, state) {
        final subManagers = switch (state) {
          SubManagerLoaded() => state.subManagers,
          SubManagerSubmitting() => state.subManagers,
          SubManagerError() => state.subManagers,
          _ => <SubManagerModel>[],
        };
        final catalog = switch (state) {
          SubManagerLoaded() => state.permissionCatalog,
          SubManagerSubmitting() => state.permissionCatalog,
          SubManagerError() => state.permissionCatalog,
          _ => <PermissionOption>[],
        };

        final isLoading = state is SubManagerLoading;
        final isSubmitting = state is SubManagerSubmitting;

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('المدراء الفرعيون',
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                        const SizedBox(height: 3),
                        Text('${subManagers.length} مدير فرعي', style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  AppButton(
                    label: 'إضافة مدير فرعي',
                    icon: Icons.add,
                    width: 170,
                    height: 40,
                    onPressed: catalog.isEmpty ? null : () => _showForm(ctx, catalog: catalog),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Expanded(
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : subManagers.isEmpty
                        ? _EmptyState(onAdd: catalog.isEmpty ? null : () => _showForm(ctx, catalog: catalog))
                        : ListView.separated(
                            itemCount: subManagers.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 10),
                            itemBuilder: (_, i) => Opacity(
                              opacity: isSubmitting ? .6 : 1,
                              child: _SubManagerCard(
                                subManager: subManagers[i],
                                onEditInfo: () => _showForm(ctx, catalog: catalog, subManager: subManagers[i]),
                                onEditPermissions: () => _showPermissions(ctx, catalog: catalog, subManager: subManagers[i]),
                                onDelete: () => _confirmDelete(ctx, subManagers[i]),
                              ),
                            ),
                          ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showForm(BuildContext context, {required List<PermissionOption> catalog, SubManagerModel? subManager}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BlocProvider.value(
        value: context.read<SubManagerCubit>(),
        child: _SubManagerFormDialog(catalog: catalog, subManager: subManager),
      ),
    );
  }

  void _showPermissions(BuildContext context, {required List<PermissionOption> catalog, required SubManagerModel subManager}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BlocProvider.value(
        value: context.read<SubManagerCubit>(),
        child: _PermissionsDialog(catalog: catalog, subManager: subManager),
      ),
    );
  }

  void _confirmDelete(BuildContext context, SubManagerModel subManager) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Row(children: [
          Icon(Icons.warning_amber_rounded, color: AppColors.danger, size: 22),
          SizedBox(width: 8),
          Text('تأكيد الحذف', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ]),
        content: Text('هل أنت متأكد من حذف "${subManager.name}"؟', style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
            onPressed: () {
              Navigator.pop(dialogContext);
              context.read<SubManagerCubit>().delete(subManager.id);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// CARD
// ============================================================================

class _SubManagerCard extends StatelessWidget {
  final SubManagerModel subManager;
  final VoidCallback onEditInfo;
  final VoidCallback onEditPermissions;
  final VoidCallback onDelete;

  const _SubManagerCard({
    required this.subManager,
    required this.onEditInfo,
    required this.onEditPermissions,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: AppColors.primarySurface, borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.manage_accounts_outlined, color: AppColors.primary, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(subManager.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                Text(subManager.email, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                if (subManager.phone != null) Text(subManager.phone!, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: subManager.permissions.isEmpty
                      ? [const Text('لا صلاحيات', style: TextStyle(fontSize: 11, color: AppColors.textHint))]
                      : subManager.permissions
                          .map((p) => Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(20)),
                                child: Text(p, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                              ))
                          .toList(),
                ),
              ],
            ),
          ),
          Column(children: [
            _ActionBtn(icon: Icons.edit_outlined, color: AppColors.primary, tooltip: 'تعديل البيانات', onTap: onEditInfo),
            const SizedBox(height: 6),
            _ActionBtn(icon: Icons.vpn_key_outlined, color: AppColors.warning, tooltip: 'تعديل الصلاحيات', onTap: onEditPermissions),
            const SizedBox(height: 6),
            _ActionBtn(icon: Icons.delete_outline, color: AppColors.danger, tooltip: 'حذف', onTap: onDelete),
          ]),
        ],
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.color, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(6),
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: color.withOpacity(.08), borderRadius: BorderRadius.circular(6)),
            child: Icon(icon, size: 16, color: color),
          ),
        ),
      );
}

class _EmptyState extends StatelessWidget {
  final VoidCallback? onAdd;
  const _EmptyState({this.onAdd});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(color: AppColors.primarySurface, borderRadius: BorderRadius.circular(20)),
            child: const Icon(Icons.manage_accounts_outlined, size: 36, color: AppColors.primary),
          ),
          const SizedBox(height: 16),
          const Text('لا يوجد مدراء فرعيون بعد', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          const Text('فوّض جزءاً من الصلاحيات لمدير فرعي', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(height: 20),
          if (onAdd != null) AppButton(label: 'إضافة مدير فرعي', icon: Icons.add, width: 190, height: 40, onPressed: onAdd),
        ]),
      );
}

// ============================================================================
// FORM DIALOG (name/email/phone + permissions on create)
// ============================================================================

class _SubManagerFormDialog extends StatefulWidget {
  final List<PermissionOption> catalog;
  final SubManagerModel? subManager;
  const _SubManagerFormDialog({required this.catalog, this.subManager});

  @override
  State<_SubManagerFormDialog> createState() => _SubManagerFormDialogState();
}

class _SubManagerFormDialogState extends State<_SubManagerFormDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _email;
  late final TextEditingController _phone;
  late Set<String> _selectedPermissions;

  bool _isSubmitting = false;
  String? _errorText;

  bool get _isEdit => widget.subManager != null;

  @override
  void initState() {
    super.initState();
    final sm = widget.subManager;
    _name = TextEditingController(text: sm?.name ?? '');
    _email = TextEditingController(text: sm?.email ?? '');
    _phone = TextEditingController(text: sm?.phone ?? '');
    _selectedPermissions = {...(sm?.permissions ?? [])};
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_isSubmitting) return;
    setState(() {
      _isSubmitting = true;
      _errorText = null;
    });

    final cubit = context.read<SubManagerCubit>();

    if (_isEdit) {
      final body = <String, dynamic>{
        'name': _name.text.trim(),
        if (_phone.text.trim().isNotEmpty) 'phone': _phone.text.trim(),
      };
      final success = await cubit.update(widget.subManager!.id, body);
      if (!mounted) return;
      if (success) {
        Navigator.pop(context);
      } else {
        final state = cubit.state;
        setState(() {
          _isSubmitting = false;
          _errorText = state is SubManagerError ? state.message : 'حدث خطأ، حاول مرة أخرى';
        });
      }
    } else {
      final body = <String, dynamic>{
        'name': _name.text.trim(),
        'email': _email.text.trim(),
        'phone': _phone.text.trim(),
        'permissions': _selectedPermissions.toList(),
      };
      final tempPassword = await cubit.create(body);
      if (!mounted) return;
      if (tempPassword != null) {
        Navigator.pop(context);
        _showTempPasswordDialog(context, name: _name.text.trim(), tempPassword: tempPassword);
      } else {
        final state = cubit.state;
        setState(() {
          _isSubmitting = false;
          _errorText = state is SubManagerError ? state.message : 'حدث خطأ، حاول مرة أخرى';
        });
      }
    }
  }

  void _showTempPasswordDialog(BuildContext context, {required String name, required String tempPassword}) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('كلمة المرور المؤقتة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('سلّم كلمة المرور هذه لـ "$name" — لن تظهر مرة أخرى:', style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(8)),
              child: SelectableText(tempPassword, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1)),
            ),
          ],
        ),
        actions: [ElevatedButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('تم'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480, maxHeight: 620),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isEdit ? 'تعديل مدير فرعي' : 'إضافة مدير فرعي',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 18),
                Flexible(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        AppTextField(label: 'الاسم', controller: _name, validator: (v) => (v == null || v.trim().isEmpty) ? 'الاسم مطلوب' : null),
                        const SizedBox(height: 14),
                        AppTextField(
                          label: 'البريد الإلكتروني',
                          controller: _email,
                          enabled: !_isEdit,
                          keyboardType: TextInputType.emailAddress,
                          validator: (v) => (!_isEdit && (v == null || v.trim().isEmpty)) ? 'البريد الإلكتروني مطلوب' : null,
                        ),
                        const SizedBox(height: 14),
                        AppTextField(label: 'رقم الهاتف', controller: _phone, keyboardType: TextInputType.phone),
                        if (!_isEdit) ...[
                          const SizedBox(height: 16),
                          const Text('الصلاحيات', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                          const SizedBox(height: 6),
                          const Text('يمكن منح صلاحيات من ضمن صلاحياتك الحالية فقط.',
                              style: TextStyle(fontSize: 11, color: AppColors.textHint)),
                          const SizedBox(height: 8),
                          Container(
                            constraints: const BoxConstraints(maxHeight: 220),
                            decoration: BoxDecoration(border: Border.all(color: AppColors.border), borderRadius: BorderRadius.circular(8)),
                            child: SingleChildScrollView(
                              child: Column(
                                children: widget.catalog
                                    .map((perm) => CheckboxListTile(
                                          dense: true,
                                          controlAffinity: ListTileControlAffinity.leading,
                                          value: _selectedPermissions.contains(perm.value),
                                          title: Text(perm.labelAr, style: const TextStyle(fontSize: 12)),
                                          subtitle: Text(perm.value, style: const TextStyle(fontSize: 10, color: AppColors.textHint)),
                                          onChanged: (checked) => setState(() {
                                            if (checked == true) {
                                              _selectedPermissions.add(perm.value);
                                            } else {
                                              _selectedPermissions.remove(perm.value);
                                            }
                                          }),
                                        ))
                                    .toList(),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                if (_errorText != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppColors.dangerSurface, borderRadius: BorderRadius.circular(8)),
                    child: Text(_errorText!, style: const TextStyle(fontSize: 12, color: AppColors.danger)),
                  ),
                ],
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(
                    child: TextButton(
                      onPressed: _isSubmitting ? null : () => Navigator.pop(context),
                      child: const Text('إلغاء', style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: AppButton(label: _isEdit ? 'حفظ' : 'إضافة', isLoading: _isSubmitting, onPressed: _submit)),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// PERMISSIONS-ONLY DIALOG (Update Sub-Manager Permissions)
// ============================================================================

class _PermissionsDialog extends StatefulWidget {
  final List<PermissionOption> catalog;
  final SubManagerModel subManager;
  const _PermissionsDialog({required this.catalog, required this.subManager});

  @override
  State<_PermissionsDialog> createState() => _PermissionsDialogState();
}

class _PermissionsDialogState extends State<_PermissionsDialog> {
  late Set<String> _selected;
  bool _isSubmitting = false;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _selected = {...widget.subManager.permissions};
  }

  Future<void> _submit() async {
    setState(() {
      _isSubmitting = true;
      _errorText = null;
    });
    final success = await context.read<SubManagerCubit>().updatePermissions(widget.subManager.id, _selected.toList());
    if (!mounted) return;
    if (success) {
      Navigator.pop(context);
    } else {
      final state = context.read<SubManagerCubit>().state;
      setState(() {
        _isSubmitting = false;
        _errorText = state is SubManagerError ? state.message : 'حدث خطأ، حاول مرة أخرى';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460, maxHeight: 560),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('صلاحيات — ${widget.subManager.name}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
              const SizedBox(height: 14),
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    children: widget.catalog
                        .map((perm) => CheckboxListTile(
                              dense: true,
                              controlAffinity: ListTileControlAffinity.leading,
                              value: _selected.contains(perm.value),
                              title: Text(perm.labelAr, style: const TextStyle(fontSize: 12)),
                              subtitle: Text(perm.value, style: const TextStyle(fontSize: 10, color: AppColors.textHint)),
                              onChanged: (checked) => setState(() {
                                if (checked == true) {
                                  _selected.add(perm.value);
                                } else {
                                  _selected.remove(perm.value);
                                }
                              }),
                            ))
                        .toList(),
                  ),
                ),
              ),
              if (_errorText != null) ...[
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: AppColors.dangerSurface, borderRadius: BorderRadius.circular(8)),
                  child: Text(_errorText!, style: const TextStyle(fontSize: 12, color: AppColors.danger)),
                ),
              ],
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: TextButton(
                    onPressed: _isSubmitting ? null : () => Navigator.pop(context),
                    child: const Text('إلغاء', style: TextStyle(color: AppColors.textSecondary)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: AppButton(label: 'حفظ الصلاحيات', isLoading: _isSubmitting, onPressed: _submit)),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
