import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/widgets/dashboard/dashboard_layout.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/constants/app_routes.dart';

import 'package:driver_app_dash/features/vehicles/data/models/vehicle_model.dart';
import 'package:driver_app_dash/features/vehicles/presentation/cubit/vehicle_cubit.dart';

class VehiclesScreen extends StatelessWidget {
  const VehiclesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DashboardLayout(
      activeRoute: AppRoutes.vehicles,
      pageTitle: 'المركبات',
      body: const _VehiclesBody(),
    );
  }
}

// ============================================================================
// VEHICLES BODY
// ============================================================================

const _statusOptions = <String, String>{
  '': 'كل الحالات',
  'active': 'نشطة',
  'inactive': 'غير نشطة',
  'maintenance': 'صيانة',
  'out_of_service': 'خارج الخدمة',
};

class _VehiclesBody extends StatefulWidget {
  const _VehiclesBody();

  @override
  State<_VehiclesBody> createState() => _VehiclesBodyState();
}

class _VehiclesBodyState extends State<_VehiclesBody> {
  String _search = '';
  String _statusFilter = '';

  @override
  void initState() {
    super.initState();
    context.read<VehicleCubit>().load();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<VehicleCubit, VehicleState>(
      listener: (ctx, state) {
        if (state is VehicleError) {
          ScaffoldMessenger.of(ctx).showSnackBar(
            SnackBar(content: Text(state.message), backgroundColor: AppColors.danger),
          );
        }
      },
      builder: (ctx, state) {
        final vehicles = switch (state) {
          VehicleLoaded() => state.vehicles,
          VehicleSubmitting() => state.vehicles,
          VehicleError() => state.vehicles ?? [],
          _ => <VehicleModel>[],
        };

        final query = _search.trim().toLowerCase();

        final filtered = vehicles.where((v) {
          final matchesSearch = query.isEmpty ||
              v.plateNo.toLowerCase().contains(query) ||
              (v.model?.toLowerCase().contains(query) ?? false) ||
              (v.type?.toLowerCase().contains(query) ?? false);
          final matchesStatus = _statusFilter.isEmpty || v.status == _statusFilter;
          return matchesSearch && matchesStatus;
        }).toList();

        final isLoading = state is VehicleLoading;
        final isSubmitting = state is VehicleSubmitting;

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ──────────────────────────────────────────────
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('إدارة المركبات',
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                        const SizedBox(height: 3),
                        Text('${vehicles.length} مركبة مسجلة',
                            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                      ],
                    ),
                  ),
                  AppButton(
                    label: 'إضافة مركبة',
                    icon: Icons.add,
                    width: 150,
                    height: 40,
                    onPressed: () => _showForm(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // ── Search + status filter ────────────────────────────────
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 42,
                      child: TextField(
                        onChanged: (v) => setState(() => _search = v),
                        decoration: InputDecoration(
                          hintText: 'بحث برقم اللوحة أو الموديل أو النوع...',
                          prefixIcon: const Icon(Icons.search, size: 18, color: AppColors.textHint),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                          filled: true,
                          fillColor: AppColors.surface,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.border)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: AppColors.primary)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    height: 42,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _statusFilter,
                        items: _statusOptions.entries
                            .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, style: const TextStyle(fontSize: 13))))
                            .toList(),
                        onChanged: (v) => setState(() => _statusFilter = v ?? ''),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ── Table ──────────────────────────────────────────────
              Expanded(
                child: isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : filtered.isEmpty
                        ? _EmptyState(onAdd: () => _showForm(ctx))
                        : _VehicleTable(
                            vehicles: filtered,
                            isSubmitting: isSubmitting,
                            onEdit: (v) => _showForm(ctx, vehicle: v),
                            onDelete: (v) => _confirmDelete(ctx, v),
                          ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showForm(BuildContext context, {VehicleModel? vehicle}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => BlocProvider.value(
        value: context.read<VehicleCubit>(),
        child: _VehicleFormDialog(vehicle: vehicle),
      ),
    );
  }

  void _confirmDelete(BuildContext context, VehicleModel vehicle) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Row(children: [
          Icon(Icons.warning_amber_rounded, color: AppColors.danger, size: 22),
          SizedBox(width: 8),
          Text('تأكيد الحذف', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
        ]),
        content: Text(
          'هل أنت متأكد من حذف المركبة "${vehicle.plateNo}"؟\nلا يمكن التراجع عن هذا الإجراء.',
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              Navigator.pop(dialogContext);
              context.read<VehicleCubit>().delete(vehicle.id);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// TABLE
// ============================================================================

class _VehicleTable extends StatelessWidget {
  final List<VehicleModel> vehicles;
  final bool isSubmitting;
  final void Function(VehicleModel) onEdit;
  final void Function(VehicleModel) onDelete;

  const _VehicleTable({
    required this.vehicles,
    required this.isSubmitting,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: const BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
              border: Border(bottom: BorderSide(color: AppColors.border)),
            ),
            child: const Row(children: [
              Expanded(flex: 3, child: _HeaderCell('رقم اللوحة')),
              Expanded(flex: 2, child: _HeaderCell('النوع')),
              Expanded(flex: 2, child: _HeaderCell('الموديل')),
              Expanded(flex: 2, child: _HeaderCell('السائق المسند', centered: true)),
              Expanded(flex: 2, child: _HeaderCell('الحالة', centered: true)),
              SizedBox(width: 90, child: _HeaderCell('إجراءات', centered: true)),
            ]),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: vehicles.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.divider),
              itemBuilder: (_, i) {
                final v = vehicles[i];
                return Opacity(
                  opacity: isSubmitting ? .6 : 1,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    child: Row(children: [
                      Expanded(
                        flex: 3,
                        child: Text(v.plateNo, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                      ),
                      Expanded(flex: 2, child: Text(v.type ?? '—', style: const TextStyle(fontSize: 13, color: AppColors.textSecondary))),
                      Expanded(flex: 2, child: Text(v.model ?? '—', style: const TextStyle(fontSize: 13, color: AppColors.textSecondary))),
                      Expanded(
                        flex: 2,
                        child: Text(v.assignedDriverName ?? '—',
                            textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                      ),
                      Expanded(flex: 2, child: Center(child: _StatusChip(status: v.status))),
                      SizedBox(
                        width: 90,
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          _ActionBtn(icon: Icons.edit_outlined, color: AppColors.primary, tooltip: 'تعديل', onTap: () => onEdit(v)),
                          const SizedBox(width: 6),
                          _ActionBtn(icon: Icons.delete_outline, color: AppColors.danger, tooltip: 'حذف', onTap: () => onDelete(v)),
                        ]),
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderCell extends StatelessWidget {
  final String label;
  final bool centered;
  const _HeaderCell(this.label, {this.centered = false});

  @override
  Widget build(BuildContext context) => Text(
        label,
        textAlign: centered ? TextAlign.center : TextAlign.start,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSecondary),
      );
}

class _StatusChip extends StatelessWidget {
  final String status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      'active' => ('نشطة', AppColors.success),
      'maintenance' => ('صيانة', AppColors.warning),
      'out_of_service' => ('خارج الخدمة', AppColors.danger),
      _ => ('غير نشطة', AppColors.textHint),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(.1), borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color)),
      ]),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.color, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(6),
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: color.withOpacity(.08), borderRadius: BorderRadius.circular(6)),
            child: Icon(icon, size: 16, color: color),
          ),
        ),
      );
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(color: AppColors.primarySurface, borderRadius: BorderRadius.circular(20)),
            child: const Icon(Icons.local_shipping_outlined, size: 36, color: AppColors.primary),
          ),
          const SizedBox(height: 16),
          const Text('لا توجد مركبات بعد', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
          const SizedBox(height: 6),
          const Text('ابدأ بإضافة أول مركبة في الأسطول', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(height: 20),
          AppButton(label: 'إضافة مركبة', icon: Icons.add, width: 160, height: 40, onPressed: onAdd),
        ]),
      );
}

// ============================================================================
// FORM DIALOG
// ============================================================================

class _VehicleFormDialog extends StatefulWidget {
  final VehicleModel? vehicle;
  const _VehicleFormDialog({this.vehicle});

  @override
  State<_VehicleFormDialog> createState() => _VehicleFormDialogState();
}

class _VehicleFormDialogState extends State<_VehicleFormDialog> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _plateNo;
  late final TextEditingController _type;
  late final TextEditingController _model;
  late final TextEditingController _description;

  String? _status; // null = leave untouched (no server-side change)

  bool _isSubmitting = false;
  String? _errorText;

  bool get _isEdit => widget.vehicle != null;

  @override
  void initState() {
    super.initState();
    final v = widget.vehicle;
    _plateNo = TextEditingController(text: v?.plateNo ?? '');
    _type = TextEditingController(text: v?.type ?? '');
    _model = TextEditingController(text: v?.model ?? '');
    _description = TextEditingController(text: v?.description ?? '');
    _status = (v?.status == 'maintenance' || v?.status == 'out_of_service') ? v!.status : null;
  }

  @override
  void dispose() {
    _plateNo.dispose();
    _type.dispose();
    _model.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_isSubmitting) return;

    setState(() {
      _isSubmitting = true;
      _errorText = null;
    });

    final body = <String, dynamic>{
      if (_type.text.trim().isNotEmpty) 'type': _type.text.trim(),
      if (_model.text.trim().isNotEmpty) 'model': _model.text.trim(),
      if (_description.text.trim().isNotEmpty) 'description': _description.text.trim(),
      if (_status != null) 'status': _status,
    };

    if (!_isEdit) {
      body['plate_no'] = _plateNo.text.trim();
    }

    final cubit = context.read<VehicleCubit>();
    final success = _isEdit ? await cubit.update(widget.vehicle!.id, body) : await cubit.create(body);

    if (!mounted) return;

    if (success) {
      Navigator.pop(context);
    } else {
      final state = cubit.state;
      setState(() {
        _isSubmitting = false;
        _errorText = state is VehicleError ? state.message : 'حدث خطأ، حاول مرة أخرى';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isEdit ? 'تعديل مركبة' : 'إضافة مركبة',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
                const SizedBox(height: 18),

                AppTextField(
                  label: 'رقم اللوحة',
                  hint: 'DXB-12345',
                  controller: _plateNo,
                  enabled: !_isEdit,
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'رقم اللوحة مطلوب' : null,
                ),
                const SizedBox(height: 14),

                AppTextField(label: 'النوع', hint: 'Truck / Van / Bus...', controller: _type),
                const SizedBox(height: 14),

                AppTextField(label: 'الموديل', hint: 'Hino 300', controller: _model),
                const SizedBox(height: 14),

                AppTextField(label: 'الوصف', hint: 'ملاحظات إضافية...', controller: _description),
                const SizedBox(height: 14),

                if (_isEdit) ...[
                  const Text('الحالة', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                  const SizedBox(height: 6),
                  Container(
                    height: 46,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceInput,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String?>(
                        value: _status,
                        isExpanded: true,
                        hint: const Text('بدون تغيير', style: TextStyle(fontSize: 13, color: AppColors.textHint)),
                        items: const [
                          DropdownMenuItem(value: null, child: Text('بدون تغيير', style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'maintenance', child: Text('صيانة', style: TextStyle(fontSize: 13))),
                          DropdownMenuItem(value: 'out_of_service', child: Text('خارج الخدمة', style: TextStyle(fontSize: 13))),
                        ],
                        onChanged: (v) => setState(() => _status = v),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'الحالتان "نشطة" و"غير نشطة" تُحسبان تلقائياً من ربط السائق وتسجيل الحضور، ولا يمكن تعيينهما يدوياً.',
                    style: TextStyle(fontSize: 11, color: AppColors.textHint, height: 1.5),
                  ),
                  const SizedBox(height: 14),
                ],

                if (_errorText != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: AppColors.dangerSurface, borderRadius: BorderRadius.circular(8)),
                    child: Text(_errorText!, style: const TextStyle(fontSize: 12, color: AppColors.danger)),
                  ),
                  const SizedBox(height: 14),
                ],

                Row(children: [
                  Expanded(
                    child: TextButton(
                      onPressed: _isSubmitting ? null : () => Navigator.pop(context),
                      child: const Text('إلغاء', style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppButton(
                      label: _isEdit ? 'حفظ' : 'إضافة',
                      isLoading: _isSubmitting,
                      onPressed: _submit,
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
