import 'package:flutter_bloc/flutter_bloc.dart';
import '../../data/datasources/sub_manager_remote_datasource.dart';
import '../../data/models/sub_manager_model.dart';

part 'sub_manager_state.dart';

class SubManagerCubit extends Cubit<SubManagerState> {
  final SubManagerRemoteDataSource _ds = SubManagerRemoteDataSource();

  SubManagerCubit() : super(SubManagerInitial());

  // Loads both the sub-manager list and the static permission catalog
  // (the checkbox matrix needs both).
  Future<void> load() async {
    if (isClosed) return;
    emit(SubManagerLoading());
    try {
      final results = await Future.wait([_ds.getSubManagers(), _ds.getPermissionCatalog()]);
      final list = results[0] as List<SubManagerModel>;
      final catalog = results[1] as List<PermissionOption>;
      if (!isClosed) emit(SubManagerLoaded(list, catalog));
    } catch (e) {
      if (!isClosed) emit(SubManagerError(e.toString()));
    }
  }

  // Returns the one-time temporary_password on success.
  Future<String?> create(Map<String, dynamic> body) async {
    if (isClosed) return null;
    final current = _currentList;
    final catalog = _currentCatalog;
    emit(SubManagerSubmitting(current, catalog));
    try {
      final res = await _ds.createSubManager(body);
      final tempPassword = res['temporary_password']?.toString() ?? '';
      final list = await _ds.getSubManagers();
      if (!isClosed) emit(SubManagerLoaded(list, catalog));
      return tempPassword;
    } catch (e) {
      if (!isClosed) emit(SubManagerError(e.toString(), current, catalog));
      return null;
    }
  }

  Future<bool> update(int id, Map<String, dynamic> body) async {
    if (isClosed) return false;
    final current = _currentList;
    final catalog = _currentCatalog;
    emit(SubManagerSubmitting(current, catalog));
    try {
      await _ds.updateSubManager(id, body);
      final list = await _ds.getSubManagers();
      if (!isClosed) emit(SubManagerLoaded(list, catalog));
      return true;
    } catch (e) {
      if (!isClosed) emit(SubManagerError(e.toString(), current, catalog));
      return false;
    }
  }

  Future<bool> updatePermissions(int id, List<String> permissions) async {
    if (isClosed) return false;
    final current = _currentList;
    final catalog = _currentCatalog;
    emit(SubManagerSubmitting(current, catalog));
    try {
      await _ds.updatePermissions(id, permissions);
      final list = await _ds.getSubManagers();
      if (!isClosed) emit(SubManagerLoaded(list, catalog));
      return true;
    } catch (e) {
      if (!isClosed) emit(SubManagerError(e.toString(), current, catalog));
      return false;
    }
  }

  Future<bool> delete(int id) async {
    if (isClosed) return false;
    final current = _currentList;
    final catalog = _currentCatalog;
    emit(SubManagerSubmitting(current, catalog));
    try {
      await _ds.deleteSubManager(id);
      final list = await _ds.getSubManagers();
      if (!isClosed) emit(SubManagerLoaded(list, catalog));
      return true;
    } catch (e) {
      if (!isClosed) emit(SubManagerError(e.toString(), current, catalog));
      return false;
    }
  }

  List<SubManagerModel> get _currentList {
    final s = state;
    if (s is SubManagerLoaded) return s.subManagers;
    if (s is SubManagerSubmitting) return s.subManagers;
    if (s is SubManagerError) return s.subManagers;
    return [];
  }

  List<PermissionOption> get _currentCatalog {
    final s = state;
    if (s is SubManagerLoaded) return s.permissionCatalog;
    if (s is SubManagerSubmitting) return s.permissionCatalog;
    if (s is SubManagerError) return s.permissionCatalog;
    return [];
  }
}
